#
# Copyright (c) 2023 Airbyte, Inc., all rights reserved.
#


class SourceTest:
    def __init__(self):
        pass
